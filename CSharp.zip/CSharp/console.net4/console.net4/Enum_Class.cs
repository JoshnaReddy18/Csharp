﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console.net4
{
    class Enum_Class
    {
    }
    public enum MyEnum
    {
        Red = 1,
        Green = 2,
        Blue = 3
    }
}
