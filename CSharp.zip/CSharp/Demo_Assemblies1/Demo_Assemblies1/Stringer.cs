﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Assemblies1
{
    class Stringer
    {
        public void StringerMethod()
        {
            Console.WriteLine("Assemblies"); ;
        }
    }
}
