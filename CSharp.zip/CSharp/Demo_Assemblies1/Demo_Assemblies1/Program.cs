﻿using System;
using System.Reflection;
using Demo_Assemblies1;

namespace Demo_Assemblies1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Stringer myStringInstance = new Stringer();
            Console.WriteLine("client mode Executes from ");
            myStringInstance.StringerMethod();
        }
    }
}
