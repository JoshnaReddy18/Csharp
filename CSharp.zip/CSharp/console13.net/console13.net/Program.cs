﻿using System;
using console13.net;

namespace console13.net
{
    class Program:Class1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Class1 obj = new Class1("joshna");
            obj.Display_Msg();
            obj.Dispose();
            
            
        }
    }
}
