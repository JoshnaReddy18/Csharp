﻿using System;
using System.Collections.Generic;
using System.Collections;

namespace Console.net6
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");
            //step1:creating object of the class(defining colection)
            //step2:adding element in the collection
            //step3:displaying element in colection
            /*var numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            foreach(var item in numbers)
            {
                System.Console.WriteLine(item);
            }
            var StudentNames = new List<string> { "virat", "dhoni", "rohith" };
            for(int i=0;i<StudentNames.Count;i++)
            {
                System.Console.WriteLine("StudentName is{0 }\n",StudentNames[i]);
            }
            
            Stack<string> Numbers = new Stack<string>();
            Numbers.Push("one");
            Numbers.Push("two");
            Numbers.Push("three");
            foreach (var item in Numbers)
            {
                System.Console.WriteLine("Collection Numbers are {0} \n", item);

                System.Console.WriteLine("removing Numbers from stack {0}\n", Numbers.Pop());
            }
            
            Queue<int> MyQue = new Queue<int>();
            MyQue.Enqueue(120);
            MyQue.Enqueue(300);
            MyQue.Enqueue(200);
            foreach(var item in MyQue)
            {
                System.Console.WriteLine("Queue elements are {0} \n",item);
            }
            System.Console.WriteLine("First Element that is removed from count is {0}",MyQue.Dequeue());
            System.Console.WriteLine("Total elements of the queue are {0}",MyQue.Count);
            System.Console.WriteLine("Type of the collection is {0}\n",MyQue.GetType());

            ArrayList MyArrayList = new ArrayList();
            MyArrayList.Add(false);
            MyArrayList.Add(123);
            MyArrayList.Add("kohli");
            MyArrayList.Add(123.12);
            foreach(var item in MyArrayList)
            {
                System.Console.WriteLine("elements of arraylist is {0}\n",item);
            }
            SortedList<string,int> Gamescore = new SortedList<string,int>();
          
             Gamescore.Add("My COD Score was ",1888);
            Gamescore.Add("My CEP Score was ", 1000);
             foreach(var item in Gamescore)
            {
                System.Console.WriteLine("score in sorted is\t {0} \t and value {1}\n",item.Key,item.Value);
            }
            Dictionary<string, string> PasswordDetails = new Dictionary<string, string>();
            PasswordDetails.Add("Instagram", "#@%$$^&");
            PasswordDetails.Add("Gmail", "*^&R^$*&");
            PasswordDetails.Add("Facebook", "^%%&^^*");
            foreach(var item in PasswordDetails)
            {
                System.Console.WriteLine("content in the dictionary with \t is:{0} \t {1}\n ",item.Key,item.Value);
            
            }
            System.Console.WriteLine("count of the elements is {0}\n", PasswordDetails.Count);
            
            Hashtable MyHashTable = new Hashtable();
            MyHashTable.Add(01, "hyd");
            MyHashTable.Add(02, "Mumbai");
            MyHashTable.Add(03, "Goa");
            foreach(DictionaryEntry item in MyHashTable)
            {
                System.Console.WriteLine("Hash code of the Element is: {0}\n",item.GetHashCode());
                System.Console.WriteLine("Content of the table is\t Key: {0} and Value:{1}\n", item.Key,item.Value);
            }
            System.Console.WriteLine("total elements of the table are {0}",MyHashTable.Count);
            */
            Stack Names = new Stack();
            Names.Push("Rohan");
            Names.Push("Rohith");
            Names.Push("Karthik");
            foreach(var item in Names)
            {
                System.Console.WriteLine("elements of stack are {0}",item);
            }
        }
    }
}
