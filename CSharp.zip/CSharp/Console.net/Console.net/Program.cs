﻿using System;

namespace Console.net
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");
            Console.WriteLine("Enter your age");
            int age=Convert.ToInt64(Console.Read)

        }
    }
}
