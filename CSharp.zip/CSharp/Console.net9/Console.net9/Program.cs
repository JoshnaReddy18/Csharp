﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Console.net9
{
    public class WeatherForecast
    {
        public DateTimeOffset Date { get; set; }
        public int TemperatureCelsius { get; set; }
        public string Summary { get; set; }
    }
    public class program
    {

        static void Main(string[] args)
        {
            var WeatherForecast = new WeatherForecast
            {
                Date = DateTime.Parse("2021-09-01"),
                TemperatureCelsius = 29,
                Summary = "Delhi Weather is too hot"

            };
            string weatherString = JsonSerializer.Serialize(WeatherForecast);
            System.Console.WriteLine("My json string is {0}",weatherString);
        }
    }
    
}
