﻿using System;

namespace ConsoleApp.net1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.Write("what is your favourite snacks?");

            string name = Console.ReadLine();
            Console.WriteLine("How many pieces can you have");
            int count = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(name);
            Console.WriteLine(count);
                            if(count>=5)
                            {
                              Console.WriteLine("Too much of eating snack is not good for health");
                            }
                            
        }
    }
}
