﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_Extern1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.ForeColor = Color.AliceBlue;
            label1.Text = "Welcome to GUI Button";
        }

        private void Form1.label1_Click(object sender, EventArgs e)
        {
            label1.Text = "Welcome to GUI Demo";
            label1.ForeColor = Color.Red;
        }
    }
}
