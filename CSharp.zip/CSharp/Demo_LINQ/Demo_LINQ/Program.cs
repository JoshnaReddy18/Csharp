﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Data.SqlTypes;


namespace Demo_LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("LINQ implementation in C#");
            int[] scores = new int[] { 20, 25, 30, 35, 40, 45, 50,90,100,120,95 };
            string[] players = new string[] { "virat", "Dhoni", "padikkal", "ABD", "Maxwell" };
            /*IEnumerable<int> scoresQuery =
                from score in scores
                where score is >= 35
                select score;
            //Executing Query

            foreach(int item in scoresQuery)
            {
                Console.WriteLine("value:{0}\n",item);
            }
            IEnumerable<int> scoresQuery =
                from score in scores
                where score is >= 35
                orderby score descending
                select score;
            Console.WriteLine("Values in descending order are\n");
            foreach (int item in scoresQuery)
            {
                Console.WriteLine(" value:{0}\n", item);
            }*/

            IEnumerable<string> playerQuery =
                from player in players
                where player is "virat" or "ABD"
               
                select player;
            //Console.WriteLine("Values in descending order are\n");
            foreach (var item in playerQuery)
            {
                Console.WriteLine(" player:{0}\n", item);
            }

        }
    }
}
