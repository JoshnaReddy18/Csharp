﻿using System;
using System.IO;

namespace Console.net8
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("File Handling");

            //step1: Creating a Connection
            FileStream fs = new FileStream("C:\\Users\\joshna.yalla\\Desktop\\Joshna.txt", FileMode.Open,FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            System.Console.WriteLine("We can Read and Display from file");
            string str = sr.ReadLine();
            while (str !=null)
            {
                System.Console.WriteLine(str);
                str = sr.ReadLine();
            }

            fs.Flush();
            fs.Close();


            FileStream fwrite = new FileStream("C:\\Users\\joshna.yalla\\Desktop\\Joshna.txt", FileMode.Append);
            StreamWriter sw = new StreamWriter(fwrite);
            System.Console.WriteLine("Write content into file");
     
            string content = System.Console.ReadLine();
            sw.Write(content);
            sw.Flush();
            fwrite.Flush();
            fwrite.Close();
        }

        
    }
}
