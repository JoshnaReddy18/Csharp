﻿using System;

namespace console.net2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your  age ");
            int age = Convert.ToInt32(Console.ReadLine());
            if(age>=18)
            {
                Console.WriteLine("Your elgible for voting");
            }
            else
            {
                Console.WriteLine("Your not elgible");
            }
            
            
        }
    }
}
