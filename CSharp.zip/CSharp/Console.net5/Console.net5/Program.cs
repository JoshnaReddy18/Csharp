﻿using System;

namespace Console.net5
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // System.Console.WriteLine("Enter your fav No");
                //string No = System.Console.ReadLine();
                //Int32.Parse(No);
                // System.Console.WriteLine("No you entered can't be converted to integer");
                throw new StudentNotFoundException("student not found", "Rohan");
            }
            /*catch(FormatException fe)
            {
                System.Console.WriteLine("Invalid Integer No",fe.Message);
                throw;

                
                
            }*/
            catch(StudentNotFoundException s)
            {
                System.Console.WriteLine("exception caught\n"+s.StudentName);
            }
            catch(OverflowException)
            {
                OverflowException a = new OverflowException();
                System.Console.WriteLine("No is too big to handle",a.Source);
            }
            catch(Exception)
            {
                System.Console.WriteLine("Some global Exception has occured");
            }
            
            finally
            {
                System.Console.WriteLine("iam joshna");
            }
            System.Console.WriteLine("Hello World");

        }
    }
}
