﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console.net5
{
    class Class1
    {

    }
    class StudentNotFoundException:Exception
    {
        public string StudentName { get; set; }
        public StudentNotFoundException() { }
        public StudentNotFoundException(string message) : base(message)
        {
            System.Console.WriteLine("Aligning base class message defined in Exception class");
            
        }
        public StudentNotFoundException(string Message,Exception InnerException) : base(Message, InnerException) { }

        public StudentNotFoundException(string Message,string studentName) : this(Message)
        {
            StudentName = studentName;
        }
    }
}
