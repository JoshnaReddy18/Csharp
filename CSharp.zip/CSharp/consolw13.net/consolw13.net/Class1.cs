﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace consolw13.net
{
    class Class1
    {
        public void Display()
        {
            Console.WriteLine("Implementing thread 1");
            for(int i=0;i<10;i++)
            {
                Console.WriteLine("\n {0}",i);
            }
            Console.WriteLine("Thread1 closes");
        }
        public void Read()
        {
            Console.WriteLine("Implementaing thread 2");
            for(int j=11;j<20;j++)
            {
                Console.WriteLine("\n {0}",j);
            }
            Console.WriteLine("\nThread 2 closes");
        }
    }
}
