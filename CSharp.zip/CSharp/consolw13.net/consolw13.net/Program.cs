﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Text;

namespace consolw13.net
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Multitasking using multithreading in C#");
            Class1 obj = new Class1();
            Console.WriteLine("Main Thread Started");
            obj.Display();
            //creating a ref of threadstart
            ThreadStart th1 = obj.Display;
            ThreadStart th2 = obj.Read;
            Thread s1 = new Thread(th1);
            Thread s2 = new Thread(th2);
            s1.Start();
            s2.Start();


            Console.WriteLine("main thread ends here");
            Console.ReadKey();

        }
    }
}
