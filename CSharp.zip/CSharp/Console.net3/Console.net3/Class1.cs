﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console.net3
{
    partial class LMS:placement
    {
        string name;
        int MobileNo;
        string Email;
        public void Display()
        {
            System.Console.WriteLine("Implementing void");
        }
    }
    partial class LMS:Assessment
    {
        public void Messege()
        {
            System.Console.WriteLine("Implementation is coming from second class");
        }
        void Assessment.MCQ_Assessment()
        {
            System.Console.WriteLine("Interface method1"); ;
        }
        void Assessment.QuestionBank()
        {
            System.Console.WriteLine("Interface method 2");
        }

    }
    abstract class placement
    {
        string Name_of_company;
        int No_of_students_placed;
        DateTime Year_of_placement;
        public void placement_record()
        {
            System.Console.WriteLine("this is abtract class");
        }
    }
    public interface Assessment
    {
        
        public void MCQ_Assessment();
        public void QuestionBank();


    }
}
