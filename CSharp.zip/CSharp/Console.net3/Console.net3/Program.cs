﻿using System;

namespace Console.net3
{
    class Program
    {
        static void Main(string[] args)
        {
            LMS Akash = new LMS();
            Akash.Display();
            Akash.Messege();
            Akash.placement_record();
            Assessment delhi = Akash;
            delhi.MCQ_Assessment();
            delhi.QuestionBank();
            

        }
    }
}
